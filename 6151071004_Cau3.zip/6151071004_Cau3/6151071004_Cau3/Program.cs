﻿using System;
using System.Web.Mail;

class SendUsingWebMail
{
    static void Main()
    {
        MailMessage mail = new MailMessage();
        mail.From = "your_email@gmail.com";
        mail.To = "receiver@gmail.com";
        mail.Subject = "Test mail via System.Web.Mail";
        mail.Body = "This is a test email.";

        SmtpMail.SmtpServer = "smtp.gmail.com:587";

        try
        {
            SmtpMail.Send(mail);
            Console.WriteLine("Mail sent!");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
