﻿using System;
using System.IO;
using System.Net;

namespace FTP_Features
{
    class Program
    {
        static string ftpServer = "ftp://localhost/";
        static string username = "ftpuser";
        static string password = "123456";

        static void Main()
        {
            Console.WriteLine("=== FTP SUPPORT DEMO ===");

            ListFiles();
            UploadFile("test.txt", "upload.txt");
            DownloadFile("upload.txt", "download.txt");
            RenameFile("upload.txt", "renamed.txt");
            DeleteFile("renamed.txt");

            Console.WriteLine("Finished!");
        }

        static FtpWebRequest CreateRequest(string path, string method)
        {
            FtpWebRequest request =
                (FtpWebRequest)WebRequest.Create(path);

            request.Method = method;
            request.Credentials =
                new NetworkCredential(username, password);

            request.UseBinary = true;
            request.UsePassive = true;
            request.KeepAlive = false;

            return request;
        }

        static void ListFiles()
        {
            var request = CreateRequest(ftpServer,
                WebRequestMethods.Ftp.ListDirectory);

            using var response =
                (FtpWebResponse)request.GetResponse();
            using var reader =
                new StreamReader(response.GetResponseStream());

            Console.WriteLine("Files on server:");
            while (!reader.EndOfStream)
                Console.WriteLine("- " + reader.ReadLine());
        }

        static void UploadFile(string local, string remote)
        {
            var request = CreateRequest(
                ftpServer + remote,
                WebRequestMethods.Ftp.UploadFile);

            byte[] data = File.ReadAllBytes(local);
            using var stream = request.GetRequestStream();
            stream.Write(data, 0, data.Length);

            Console.WriteLine("Upload OK");
        }

        static void DownloadFile(string remote, string local)
        {
            var request = CreateRequest(
                ftpServer + remote,
                WebRequestMethods.Ftp.DownloadFile);

            using var response =
                (FtpWebResponse)request.GetResponse();
            using var ftpStream =
                response.GetResponseStream();
            using var fileStream =
                new FileStream(local, FileMode.Create);

            ftpStream.CopyTo(fileStream);
            Console.WriteLine("Download OK");
        }

        static void RenameFile(string oldName, string newName)
        {
            var request = CreateRequest(
                ftpServer + oldName,
                WebRequestMethods.Ftp.Rename);

            request.RenameTo = newName;
            request.GetResponse();
            Console.WriteLine("Rename OK");
        }

        static void DeleteFile(string file)
        {
            var request = CreateRequest(
                ftpServer + file,
                WebRequestMethods.Ftp.DeleteFile);

            request.GetResponse();
            Console.WriteLine("Delete OK");
        }
    }
}
