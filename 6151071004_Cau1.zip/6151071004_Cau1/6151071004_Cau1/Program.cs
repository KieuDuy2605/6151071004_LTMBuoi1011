﻿using System;
using System.IO;
using System.Net;

namespace FTP_Demo
{
    class Program
    {
        // ====== CẤU HÌNH FTP ======
        static string ftpServer = "ftp://example.com/";
        static string username = "ftp_user";
        static string password = "ftp_password";

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("===== FTP CLIENT (.NET C#) =====");
                Console.WriteLine("1. Upload file");
                Console.WriteLine("2. Download file");
                Console.WriteLine("3. List files");
                Console.WriteLine("4. Delete file");
                Console.WriteLine("0. Exit");
                Console.Write("Choose: ");

                string choice = Console.ReadLine();
                Console.WriteLine();

                switch (choice)
                {
                    case "1":
                        Upload();
                        break;
                    case "2":
                        Download();
                        break;
                    case "3":
                        ListFiles();
                        break;
                    case "4":
                        Delete();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }

                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        // ====== UPLOAD ======
        static void Upload()
        {
            Console.Write("Local file path: ");
            string localFile = Console.ReadLine();

            Console.Write("FTP file name: ");
            string ftpFileName = Console.ReadLine();

            string ftpPath = ftpServer + ftpFileName;

            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpPath);
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.Credentials = new NetworkCredential(username, password);

            byte[] data = File.ReadAllBytes(localFile);
            request.ContentLength = data.Length;

            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            {
                Console.WriteLine("Upload success: " + response.StatusDescription);
            }
        }

        // ====== DOWNLOAD ======
        static void Download()
        {
            Console.Write("FTP file name: ");
            string ftpFileName = Console.ReadLine();

            Console.Write("Save to local path: ");
            string localPath = Console.ReadLine();

            string ftpPath = ftpServer + ftpFileName;

            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpPath);
            request.Method = WebRequestMethods.Ftp.DownloadFile;
            request.Credentials = new NetworkCredential(username, password);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            using (Stream ftpStream = response.GetResponseStream())
            using (FileStream fileStream = new FileStream(localPath, FileMode.Create))
            {
                ftpStream.CopyTo(fileStream);
            }

            Console.WriteLine("Download completed!");
        }

        // ====== LIST FILE ======
        static void ListFiles()
        {
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpServer);
            request.Method = WebRequestMethods.Ftp.ListDirectory;
            request.Credentials = new NetworkCredential(username, password);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                Console.WriteLine("Files on FTP:");
                while (!reader.EndOfStream)
                {
                    Console.WriteLine("- " + reader.ReadLine());
                }
            }
        }

        // ====== DELETE FILE ======
        static void Delete()
        {
            Console.Write("FTP file name to delete: ");
            string ftpFileName = Console.ReadLine();

            string ftpPath = ftpServer + ftpFileName;

            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpPath);
            request.Method = WebRequestMethods.Ftp.DeleteFile;
            request.Credentials = new NetworkCredential(username, password);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            {
                Console.WriteLine("Delete success: " + response.StatusDescription);
            }
        }
    }
}
